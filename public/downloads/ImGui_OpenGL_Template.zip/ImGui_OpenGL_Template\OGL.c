// OGL.c : Win32 + OpenGL + Dear ImGui (minimal example)
#define _CRT_SECURE_NO_WARNINGS

// win32 headers
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

// OpenGL related headers
#include <gl/GL.h>

//================================IMGUI==============================================
// ImGui is a C++ library, so run.bat compiles this file as C++ using /TP
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_opengl2.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

void IMGUI_initialize(void);
void IMGUI_display(void);
void IMGUI_uninitialize(void);

static bool g_ImGuiInitialized = false;

// values controlled from the ImGui window
float gClearColor[3] = { 0.1f, 0.1f, 0.1f };
bool  gRotate = true;
//===================================================================================

// OpenGL related libraries
#pragma comment(lib, "opengl32.lib")

// Macros
#define WIN_WIDTH 800
#define WIN_HEIGHT 600

// Global function declarations
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

// Global variable declarations
BOOL gbActiveWindow = FALSE;
BOOL gbEscapeKeyIsPressed = FALSE;
BOOL gbFullScreen = FALSE;

HWND ghwnd = NULL;
DWORD dwStyle;
WINDOWPLACEMENT wpPrev;

// Variables related to file I/O
char gszLogFileName[] = "Log.txt";
FILE *gpFile = NULL;

// OpenGL related global variables
HDC ghdc = NULL;
HGLRC ghrc = NULL;

// Rotation angle of triangle
float angle = 0.0f;

// Entry-point function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int iCmdShow)
{
    // Function declarations
    int initialize(void);
    void display(void);
    void update(void);
    void uninitialize(void);

    // Variable declarations
    WNDCLASSEX wndclass;
    HWND hwnd;
    MSG msg;
    TCHAR szAppName[] = TEXT("OGL_ImGui");
    BOOL bDone = FALSE;

    // code
    // Create log file
    gpFile = fopen(gszLogFileName, "w");
    if (gpFile == NULL)
    {
        MessageBox(NULL, TEXT("Log file creation failed!"), TEXT("Error!"), MB_OK);
        exit(0);
    }
    else
    {
        fprintf(gpFile, "Program started successfully \n");
    }

    // Window class initialization
    wndclass.cbSize = sizeof(WNDCLASSEX);
    wndclass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wndclass.cbClsExtra = 0;
    wndclass.cbWndExtra = 0;
    wndclass.lpfnWndProc = WndProc;
    wndclass.hInstance = hInstance;
    wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
    wndclass.lpszClassName = szAppName;
    wndclass.lpszMenuName = NULL;
    wndclass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    // Registration of window class
    RegisterClassEx(&wndclass);

    // Find screen center coordinates
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Create window
    hwnd = CreateWindowEx(WS_EX_APPWINDOW,
                          szAppName,
                          TEXT("OGL + ImGui"),
                          WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_VISIBLE,
                          screenWidth / 2 - WIN_WIDTH / 2,
                          screenHeight / 2 - WIN_HEIGHT / 2,
                          WIN_WIDTH,
                          WIN_HEIGHT,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ghwnd = hwnd;

    // Show window
    ShowWindow(hwnd, iCmdShow);
    UpdateWindow(hwnd);

    // Initialize
    int result = initialize();
    if (result != 0)
    {
        fprintf(gpFile, "initialize() failed \n");
        DestroyWindow(hwnd);
        hwnd = NULL;
    }
    else
    {
        fprintf(gpFile, "initialize() completed successfully \n");
    }

    // Set this window as foreground and active window
    SetForegroundWindow(hwnd);
    SetFocus(hwnd);

    // Game loop
    while (bDone == FALSE)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            if (msg.message == WM_QUIT)
            {
                bDone = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
            if (gbActiveWindow == TRUE)
            {
                if (gbEscapeKeyIsPressed == TRUE)
                {
                    bDone = TRUE;
                }

                // Render
                display();

                // Update
                update();
            }
        }
    }

    // Uninitialize
    uninitialize();

    return ((int)msg.wParam);
}

// Callback function
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
    // Function declarations
    void toggleFullscreen(void);
    void resize(int, int);

//================================IMGUI==============================================
    // Give every window message to ImGui first (mouse, keyboard, ...)
    if (ImGui_ImplWin32_WndProcHandler(hwnd, iMsg, wParam, lParam))
        return TRUE;
//===================================================================================

    // code
    switch (iMsg)
    {
    case WM_CREATE:
        ZeroMemory((void *)&wpPrev, sizeof(WINDOWPLACEMENT));
        wpPrev.length = sizeof(WINDOWPLACEMENT);
        break;
    case WM_SETFOCUS:
        gbActiveWindow = TRUE;
        break;
    case WM_KILLFOCUS:
        gbActiveWindow = FALSE;
        break;
    case WM_ERASEBKGND:
        return (0);
    case WM_SIZE:
        resize(LOWORD(lParam), HIWORD(lParam));
        break;
    case WM_KEYDOWN:
        switch (wParam)
        {
        case VK_ESCAPE:
            gbEscapeKeyIsPressed = TRUE;
            break;
        default:
            break;
        }
        break;
    case WM_CHAR:
        switch (wParam)
        {
        case 'F':
        case 'f':
            toggleFullscreen();
            break;
        default:
            break;
        }
        break;
    case WM_CLOSE:
        DestroyWindow(hwnd);
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        break;
    }

    return (DefWindowProc(hwnd, iMsg, wParam, lParam));
}

void toggleFullscreen(void)
{
    // Variable declarations
    MONITORINFO mi;

    // code
    if (gbFullScreen == FALSE)
    {
        dwStyle = GetWindowLong(ghwnd, GWL_STYLE);
        if (dwStyle & WS_OVERLAPPEDWINDOW)
        {
            ZeroMemory((void *)&mi, sizeof(MONITORINFO));
            mi.cbSize = sizeof(MONITORINFO);

            if (GetWindowPlacement(ghwnd, &wpPrev) && GetMonitorInfo(MonitorFromWindow(ghwnd, MONITORINFOF_PRIMARY), &mi))
            {
                SetWindowLong(ghwnd, GWL_STYLE, dwStyle & ~WS_OVERLAPPEDWINDOW);
                SetWindowPos(ghwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOZORDER | SWP_FRAMECHANGED);
            }
        }
        gbFullScreen = TRUE;
    }
    else
    {
        SetWindowPlacement(ghwnd, &wpPrev);
        SetWindowLong(ghwnd, GWL_STYLE, dwStyle | WS_OVERLAPPEDWINDOW);
        SetWindowPos(ghwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_FRAMECHANGED);
        gbFullScreen = FALSE;
    }
}

int initialize(void)
{
    // Function declarations
    void printGLInfo(void);
    void resize(int, int);

    // Variable declarations
    PIXELFORMATDESCRIPTOR pfd;
    int iPixelFormatIndex = 0;

    // code
    ZeroMemory((void *)&pfd, sizeof(PIXELFORMATDESCRIPTOR));

    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cRedBits = 8;
    pfd.cGreenBits = 8;
    pfd.cBlueBits = 8;
    pfd.cAlphaBits = 8;
    pfd.cDepthBits = 32;

    // Get DC
    ghdc = GetDC(ghwnd);
    if (ghdc == NULL)
    {
        fprintf(gpFile, "GetDC function failed! \n");
        return (-1);
    }

    // Get matching pixel format index
    iPixelFormatIndex = ChoosePixelFormat(ghdc, &pfd);
    if (iPixelFormatIndex == 0)
    {
        fprintf(gpFile, "ChoosePixelFormat function failed! \n");
        return (-2);
    }

    // Select the pixel format
    if (SetPixelFormat(ghdc, iPixelFormatIndex, &pfd) == FALSE)
    {
        fprintf(gpFile, "SetPixelFormat function failed! \n");
        return (-3);
    }

    // Create rendering context
    ghrc = wglCreateContext(ghdc);
    if (ghrc == NULL)
    {
        fprintf(gpFile, "wglCreateContext function failed! \n");
        return (-4);
    }

    // Make rendering context current
    if (wglMakeCurrent(ghdc, ghrc) == FALSE)
    {
        fprintf(gpFile, "wglMakeCurrent function failed! \n");
        return (-5);
    }

    printGLInfo();

    // From here onwards OpenGL code starts
    glShadeModel(GL_SMOOTH);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

//================================IMGUI==============================================
    // ImGui must be initialized AFTER the OpenGL context is created
    IMGUI_initialize();
    g_ImGuiInitialized = true;
//===================================================================================

    // Warmup resize
    resize(WIN_WIDTH, WIN_HEIGHT);

    return (0);
}

void printGLInfo(void)
{
    // code
    fprintf(gpFile, "OPENGL INFORMATION \n");
    fprintf(gpFile, "****************** \n");
    fprintf(gpFile, "OpenGL Vendor : %s \n", glGetString(GL_VENDOR));
    fprintf(gpFile, "OpenGL Renderer : %s \n", glGetString(GL_RENDERER));
    fprintf(gpFile, "OpenGL Version : %s \n", glGetString(GL_VERSION));
    fprintf(gpFile, "****************** \n");
}

void resize(int width, int height)
{
    // code
    if (height <= 0)
    {
        height = 1;
    }

    glViewport(0, 0, (GLsizei)width, (GLsizei)height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Simple orthographic projection keeping aspect ratio
    float aspect = (float)width / (float)height;
    glOrtho(-aspect, aspect, -1.0, 1.0, -1.0, 1.0);
}

void display(void)
{
    // code
//================================IMGUI==============================================
    // Background color comes from the ImGui color editor
    glClearColor(gClearColor[0], gClearColor[1], gClearColor[2], 1.0f);
//===================================================================================
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glRotatef(angle, 0.0f, 0.0f, 1.0f);

    // Triangle
    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 0.6f, 0.0f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(-0.6f, -0.5f, 0.0f);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(0.6f, -0.5f, 0.0f);
    glEnd();

//================================IMGUI==============================================
    // Draw ImGui on top of the scene, just before SwapBuffers
    IMGUI_display();
//===================================================================================

    // Swap the buffers
    SwapBuffers(ghdc);
}

void update(void)
{
    // code
    if (gRotate)
    {
        angle = angle + 0.05f;
        if (angle >= 360.0f)
        {
            angle = angle - 360.0f;
        }
    }
}

void uninitialize(void)
{
    // Function declarations
    void toggleFullscreen(void);

    // code
//================================IMGUI==============================================
    // Shutdown ImGui BEFORE the OpenGL context is deleted
    IMGUI_uninitialize();
//===================================================================================

    // If fullscreen, restore to normal before exiting
    if (gbFullScreen == TRUE)
    {
        toggleFullscreen();
    }

    // Release rendering context
    if (wglGetCurrentContext() == ghrc)
    {
        wglMakeCurrent(NULL, NULL);
    }

    // Delete the rendering context
    if (ghrc)
    {
        wglDeleteContext(ghrc);
        ghrc = NULL;
    }

    // Release the DC
    if (ghdc)
    {
        ReleaseDC(ghwnd, ghdc);
        ghdc = NULL;
    }

    // Destroy window
    if (ghwnd)
    {
        DestroyWindow(ghwnd);
        ghwnd = NULL;
    }

    // Close the log file
    if (gpFile)
    {
        fprintf(gpFile, "Program terminated successfully \n");
        fclose(gpFile);
        gpFile = NULL;
    }
}

//================================IMGUI==============================================

void IMGUI_initialize(void)
{
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_InitForOpenGL(ghwnd);   // Win32  : input, mouse, keyboard
    ImGui_ImplOpenGL2_Init();               // OpenGL : draws the ImGui windows
}

void IMGUI_display(void)
{
    // Start the Dear ImGui frame
    ImGui_ImplOpenGL2_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    // Our UI : one window with a text, a color editor and a checkbox
    ImGui::Begin("Hello, ImGui!");
    ImGui::Text("This is my first ImGui window");
    ImGui::ColorEdit3("Background", gClearColor);
    ImGui::Checkbox("Rotate triangle", &gRotate);
    ImGui::End();

    // Rendering
    ImGui::Render();
    ImGui_ImplOpenGL2_RenderDrawData(ImGui::GetDrawData());
}

void IMGUI_uninitialize(void)
{
    if (g_ImGuiInitialized)
    {
        ImGui_ImplOpenGL2_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_ImGuiInitialized = false;
    }
}

//===================================================================================
