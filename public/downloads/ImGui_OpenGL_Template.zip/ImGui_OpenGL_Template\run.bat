@echo off

if exist bin\OGL.exe del bin\OGL.exe
if exist intermediate\*.obj del intermediate\*.obj
if exist Log.txt del Log.txt

if not exist intermediate mkdir intermediate
if not exist bin mkdir bin

cl.exe /c /EHsc /std:c++17 /TP /I external/imgui ^
    OGL.c ^
    external/imgui/imgui.cpp ^
    external/imgui/imgui_draw.cpp ^
    external/imgui/imgui_widgets.cpp ^
    external/imgui/imgui_tables.cpp ^
    external/imgui/imgui_demo.cpp ^
    external/imgui/imgui_impl_opengl2.cpp ^
    external/imgui/imgui_impl_win32.cpp ^
    /Fo"intermediate\\"

link.exe intermediate\OGL.obj intermediate\imgui.obj intermediate\imgui_demo.obj ^
    intermediate\imgui_draw.obj intermediate\imgui_widgets.obj intermediate\imgui_tables.obj ^
    intermediate\imgui_impl_opengl2.obj intermediate\imgui_impl_win32.obj ^
    User32.lib GDI32.lib OpenGL32.lib ^
    /SUBSYSTEM:WINDOWS /OUT:bin\OGL.exe

bin\OGL.exe
