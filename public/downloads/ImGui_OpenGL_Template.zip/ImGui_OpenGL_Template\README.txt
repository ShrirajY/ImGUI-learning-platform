ImGui + OpenGL starter (Win32, OpenGL fixed-function, Dear ImGui 1.92.0 WIP)
===========================================================================

WHAT YOU NEED
  Windows 10/11 + Visual Studio 2022 (free Community edition is fine)
  with the workload "Desktop development with C++".

HOW TO RUN
  1. Open "x64 Native Tools Command Prompt for VS 2022" (Start menu)
  2. cd into this folder
  3. run.bat
       - compiles OGL.c (as C++, /TP) + Dear ImGui into intermediate\
       - links bin\OGL.exe and starts it

FOLDER LAYOUT
  external\imgui\   Dear ImGui core + Win32 platform backend + OpenGL2 renderer backend
  OGL.c             your program: window, OpenGL rendering, ImGui UI
                    (compiled as C++ with /TP because ImGui is a C++ library)
  run.bat           build + run script
  intermediate\     .obj files (created by run.bat)
  bin\              OGL.exe   (created by run.bat)

USING IT IN YOUR OWN PROJECT
  Every ImGui part of OGL.c is marked with  //=====...IMGUI...=====  banners.
  The real work is in 3 functions at the bottom: IMGUI_initialize(),
  IMGUI_display() and IMGUI_uninitialize(). Copy those + external\imgui.

KEYS:  ESC = quit,  F = fullscreen
